############################################################################################
#################################         Visualizing Data        ##########################
############################################################################################

## First, re-import RData, if have cleaned it

load("Cleaned-e2m2.Rdata")

# Look at your RData environment, and check it

View(e2m2)
head(e2m2)
str(e2m2)

require(dplyr)

# You are good for the next steps

#####################     Arrange data   #####################

######## Base function, tapply().

### In the following, we will use these two base functions to get a monthly Parasite load.
# First Create a parasite load, according to data story, it was recorded as Positive fields from 200 total fields.
# Calculate the parasite load as percentage of positive field ((Para/200)*100). Read the data story to understand.
# Create the new variable, named ParLoad


e2m2$ParLoad <- (e2m2$Para/200) * 100


attach(e2m2)



boxplot(Forearm~Sex,
        names=c("Females","Males"),
        col=c(2:3),
        main="Forearm by Sex",
        xlab="Sex",
        ylab="Forearm (mm)",
        ylim=c(0,100))

####

plot(Weight~Forearm,
     main = "Weight/Forearm",
     ylab ="Weight (g)",
     xlab = "Forearm (mm)",
     pch=20,
     col="black")

lmfit <- lm(Weight~Forearm)

abline(unname(lmfit$coefficients),col="red",lwd=2)