#### write a function that will calculate the area of a circle when you give it's radius








####Now, add a for-loop to obtain the area of circles that have a range of radius






#### finally if this area exceeds a limit l we want to print "circle is too big"