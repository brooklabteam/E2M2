
## ----SIRode1-------------------------------------------------------------
sir <- function(t,y,parms){
  with(c(as.list(y),parms),{
    dSdt <- -beta*S*I/N
    dIdt <- beta*S*I/N - gamma*I
    list(c(dSdt,dIdt))
  })
}

## ----SIRode2-------------------------------------------------------------
pop.SI <- c(S = 1000,I = 2)       # Starting population structure
values <- c(beta = 1.1,           # Transmission coefficient
            gamma = 1/12,         # Recovery rate
            N=1000)               # Population size (constant)

## ----SIRode3-------------------------------------------------------------
R0 <- values["beta"]/values["gamma"] # value of R0
R0

## ----SIRode4-------------------------------------------------------------
library(deSolve)

times <- seq(0,71,by=2)

ts.sir <- data.frame(lsoda(
  y = pop.SI,                   # Initial conditions for population
  times = times,   # Timepoints for evaluation
  func = sir,                   # Function to evaluate
  parms = values                # Vector of parameters
  ))

## ----SIRodePlot----------------------------------------------------------
plot(ts.sir[,"time"],ts.sir[,"I"], xlab="Time", ylab="Infected", type="l")

## ----SIRode5-------------------------------------------------------------
cases <- rbinom(nrow(ts.sir),floor(ts.sir[,"I"]),0.7)

## ----SIRode7-------------------------------------------------------------
underfit <- lm(cases ~ 1)

## ----SIRode8-------------------------------------------------------------
## pull out every 2nd measurement
##  - the 'seq' command creates an index 1,3,5, ...
new.time <- ts.sir[seq(1,nrow(ts.sir), by=2),"time"]
## we repeat them twice to have something of same length as the data
## and add 1/2 of the difference between two time-steps, since our average of cases should also reflects the average time-step
new.time <- rep(new.time,each=2)+0.5*diff(times)[1]

## we fit this using a linear model
overfit <- lm(cases ~ as.factor(new.time)-1)

## ----SIRodePlot2---------------------------------------------------------
plot(ts.sir[,"time"],cases, pch=19, xlab="Time", ylab="Infected")
points(unique(new.time),overfit$coeff, type="b", col=2,lty=1,pch=19, cex=0.6)
points(unique(new.time),rep(underfit$coeff,length(unique(new.time))), col=4, pch=19, cex=0.6, type="b")

## ----SIRode9-------------------------------------------------------------
like.cases <- function(par,cases,pop.SI=c(S = 1000,I = 2),do.plot=FALSE){

      #plug 'params' into a named vector (which lsoda needs)
      values <- c(beta = par[1],          # Transmission coefficient
                 gamma = par[2],          # Recovery rate
                 N=as.numeric(pop.SI["S"])) # Assume S=N

      #run our model with these parameters
      ts.sir <- data.frame(lsoda(
          y = pop.SI,                   # Initial conditions for population
          times = times,                # Timepoints for evaluation
          func = sir,                   # Function to evaluate
          parms = values                # Vector of parameters
       ))

      #put obs. prob. on logit scale, to avoid issues where >1 or <0
      rho <- exp(par[3])/(1+exp(par[3]))

     #get the likelihood
     like <- dbinom(cases,floor(ts.sir[,"I"]),
                    rho, ## put obs on logit scale
                    log=TRUE)

     #plot if wanted (this gives us a way to understand problems)
     if (do.plot){
     par(mfrow=c(2,1))   # make 2 rows and 1 column
     plot(ts.sir[,"time"],ts.sir[,"I"]*rho,type="l",col=2,
          ylim=range(c(ts.sir[,"I"]*rho,cases)),xlab="time", ylab="cases")
     legend("topright",legend=c("cases (data)", "estimated cases"),
            pch=c(19,NA),lty=c(NA,1),col=c(1,2), bty="n", cex=0.5)
     points(ts.sir[,"time"],cases,pch=19,col=1)
     plot(ts.sir[,"time"],-like,xlab="time", ylab="log likelihood",
          pch=15, cex=0.5)
     }

     # some edits to make a finite number come out! If more cases are reported
     #  than are observed, the likelihood is -infinity, and we can't add like
     like[like==-Inf] <- -exp(200)
     like[like==Inf] <- exp(200)

     return(-sum(like))

}

## ----SIRode10------------------------------------------------------------
test1 <- like.cases(par=c(1.1,1/12,-10),cases=cases,
                      pop.SI=c(S = 1000,I = 2), do.plot=TRUE)
test1

## ----SIRode11------------------------------------------------------------
test2 <- like.cases(par=c(1.1,1/12,0),cases=cases,
                      pop.SI=c(S = 1000,I = 2), do.plot=TRUE)
test2

test3 <- like.cases(par=c(1.1,1/5,log(0.7/(1-0.7))),cases=cases,
                      pop.SI=c(S = 1000,I = 2), do.plot=TRUE)
test3


## ----SIRode12------------------------------------------------------------
tmp <- optim(par=c(1.0,0.15,log(0.6/(1-0.6))),
             fn=like.cases,cases=cases,do.plot=FALSE,
                      pop.SI=c(S = 1000,I = 2),
             method="Nelder-Mead")
## repeat starting at the output conditions to give more search space
tmp <- optim(par=tmp$par,
             fn=like.cases,cases=cases,do.plot=FALSE,
                      pop.SI=c(S = 1000,I = 2),
             method="Nelder-Mead")

tmp

## ----SIRode12a-----------------------------------------------------------

values[1:2]   #This is what we set in the first section for beta, gamma
tmp$par[1:2]  #This is what optim thinks the parameters should be

0.7  #This is our observation probability
exp(tmp$par[3])/(1+exp(tmp$par[3]))  #This is what optim thinks it is


## ----SIRodePlot3---------------------------------------------------------

pred.ts.sir <- data.frame(lsoda(
  y = pop.SI,                   # Initial conditions for population
  times = times,   # Timepoints for evaluation
  func = sir,                   # Function to evaluate
  parms = c(beta=tmp$par[1],
            gamma=tmp$par[2],N=1000)                # Vector of parameters
  ))

plot(ts.sir[,"time"],cases, pch=19, xlab="Time", ylab="Infected")
points(ts.sir[,"time"],ts.sir[,"I"]*0.7, type="l", col="grey")
points(pred.ts.sir[,"time"],pred.ts.sir[,"I"]*
         exp(tmp$par[3])/(1+exp(tmp$par[3])),  type="l",col="orange")


## ----SIRode13------------------------------------------------------------

#underfit
AIC(underfit)

#overfit
AIC(overfit)

#mech fit - remember that our function is designed to minimize! so do subtraction
2*2-2*(-tmp$value)


## ----SIRode14------------------------------------------------------------
#reduce magnitude by 50% (x by 0.5)
pred.ts.sir.0.5 <- data.frame(lsoda(y = pop.SI,
  times = times,
  func = sir,
  parms = c(beta=0.5*tmp$par[1],gamma=tmp$par[2],N=1000)))

#reduce magnitude by 50% (x by 1.5)
pred.ts.sir.1.5 <- data.frame(lsoda(y = pop.SI,
  times = times,
  func = sir,
  parms = c(beta=1.5*tmp$par[1],gamma=tmp$par[2],N=1000)))


## ----SIRodePlot4---------------------------------------------------------
plot(ts.sir[,"time"],cases, pch=19, xlab="Time", ylab="Infected", ylim=c(0,600))
points(ts.sir[,"time"],ts.sir[,"I"]*0.7, type="l", col="grey")
points(pred.ts.sir[,"time"],pred.ts.sir[,"I"]*
         exp(tmp$par[3])/(1+exp(tmp$par[3])),  type="l",col="orange")
points(pred.ts.sir.0.5[,"time"],pred.ts.sir.0.5[,"I"]*
         exp(tmp$par[3])/(1+exp(tmp$par[3])),  type="l",col="orange", lty=2)
points(pred.ts.sir.1.5[,"time"],pred.ts.sir.1.5[,"I"]*
         exp(tmp$par[3])/(1+exp(tmp$par[3])),  type="l",
        col="orange", lty=3)


