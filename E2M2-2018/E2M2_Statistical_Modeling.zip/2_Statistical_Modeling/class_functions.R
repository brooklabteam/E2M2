# Run Multimodel selection 
all.mixed.neg.binomial<-function(r, p, random){
  require(lme4)
  colnames(r)="y"
  dat<-data.frame(r, p, random)
  combs <- do.call(expand.grid, rep(list(c(FALSE, TRUE)), ncol(p)))[-1, ]
  vars <- apply(combs, 1, function(i) names(p)[i])
  #
  vars<- vars[lapply(vars, length)>=4]    # To select only models with up to this number of variables
  #
  combs <- paste("y ~", lapply(vars, paste, collapse=" + ")," + (1|random)", sep = "")
  formula <- lapply(combs, as.formula)
  fit.aic<-vector()
  for (i in 1:length(combs)) fit.aic<-append(fit.aic, print(as.vector(AIC(glmer.nb(formula[[i]], data=dat)))))   
  data.frame(cbind(fit.aic, model=c(1:length(fit.aic)), combs))
}

# Backtransform estimates from a negative binomial model
get.estimates.nb=function(estimate, s.error, p.value){
  exp.estimate=exp(estimate)
  upper.ci=estimate+1.96*s.error
  lower.ci=estimate-1.96*s.error
  upper.ci=exp(upper.ci)
  lower.ci=exp(lower.ci)
  sig='';if(p.value<0.1)sig='.';if(p.value<0.05)sig='*';if(p.value<0.01)sig='**';if(p.value<0.001)sig='***'
  new.estimate=paste(round(exp.estimate,2),' (',round(lower.ci,2),'-',round(upper.ci,2),')',sig,sep='')
  return(new.estimate)
}